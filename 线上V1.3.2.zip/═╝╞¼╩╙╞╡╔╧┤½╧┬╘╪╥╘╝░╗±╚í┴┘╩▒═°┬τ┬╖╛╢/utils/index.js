export const Request = (params) => {
  return new Promise((resolve, reject) => {
    wx.request({
      ...params,
      success: res => { resolve(res) },
      fail: err => { reject(err) }
    })
  });
}

export const ShowToastLoading=(title)=>{
  wx.showToast({
    title: title,
    icon:"loading",
    mask:true
  })
}
//上传文件到云存储
export const UploadFile = ({ cloudPath }, { filePath }) => {
  return new Promise((resolve, reject) => {
    wx.cloud.uploadFile({
      cloudPath: cloudPath, // 上传至云端的路径
      filePath: filePath ? filePath : '', // 小程序临时文件路径
      success: res => {
        resolve(res);
      },
      fail: err => {
        console.log(err);
        console.log("filePath", filePath)
      }
    })
  });
}

export const ShowModal = (title, content)=>{
  return new Promise((resolve, reject) =>{
    wx.showModal({
      title: title == '' ? '提示' : title,
      content: content == '' ? '这是一个模态弹窗' : content,
      success(res) {
        resolve(res)
      },
      fail(err){
        reject(err)
      }
    })
  })
  
}

export const ShowToast = (title, icon) => {
  return new Promise((resolve, reject) => {
    wx.showToast({
      title: title,
      icon: icon==''?'success':icon
    })
  })
}
 
export const CallFunction = (name,data) => {
  return new Promise((resolve, reject) =>{
    wx.cloud.callFunction({
      name: name,
      data: {
        ...data
      }
    }).then(res => {resolve(res)})
  })
}
   
export const ShowLoading = (title) => {
  return new Promise((resolve, reject) => {
    wx.showLoading({
      title: title===''?'加载中':title,
      mask:true
    })
  })
}

//选择封面
export const ChooseImage = () => {
  return new Promise((resolve, reject) => {
    wx.chooseImage({
      count: 1,
      sizeType: ['original', 'compressed'],
      sourceType: ['album', 'camera'],
      success(res) {
        // tempFilePath可以作为img标签的src属性显示图片
        const tempFilePaths = res.tempFilePaths
        resolve(res)
      },
      fail(err){
        ShowToast("选择图片时出错",'none')
      }
    })
  })
}

//选择视频
export const ChooseVideo = () => {
  return new Promise((resolve, reject) => {
    wx.chooseVideo({
      sourceType: ['album', 'camera'],
      maxDuration: 60,
      camera: 'back',
      success(res) {
        resolve(res)
      },
      fail(err) {
        // reject(err);
        resolve(err);
        ShowToast("选择视频时出错", 'none')
      }
    })
  })
}
//上传资源到存储
//cloudPath==''上传视频，！=''上床图片
export const UploadforVideo = (cloudPath, filePath) => {
  var name_mp4 = new Date().getTime() + "_" + Math.ceil(Math.random() * 100) + ".mp4";
  var name_jpg = new Date().getTime() + "_" + Math.ceil(Math.random() * 100) + ".jpg";
  return new Promise((resolve, reject) => {
    wx.cloud.uploadFile({
      cloudPath: cloudPath ==''? 'beg/videos/' + name_mp4: 'beg/videos/cover/' + name_jpg, // 上传至云端的路径
      filePath: filePath, // 小程序临时文件路径
      success: res => {
        // console.log(res);
        // 返回文件 ID
        // console.log(res.fileID)
        resolve(res.fileID)
      },
      fail: console.error
    })
  })
}

//上传到数据库
export const dbAdd = (table_name,params) => {
  return new Promise((resolve, reject) => {
    wx.cloud.database().collection(table_name).add({
      // data 字段表示需新增的 JSON 数据
      data: {
        ...params
      },
      success: function (res) {
        // res 是一个对象，其中有 _id 字段标记刚创建的记录的 id
        resolve(res)
      }
    })
  })
}

//转成时间
export const Transformation2Time = (dateNum)=>{
  var a = new Date(dateNum);
  return a.getFullYear() + "-" + (a.getMonth() + 1) + "-" + a.getDate() + "     " + a.getHours() + ":" + a.getMinutes() + ":" + a.getSeconds()
}

//转成时间
export const Transformation2SingleTime = (dateNum) => {
  var a = new Date(dateNum);
  var day="";
  if (a.getDate()<10){
    day = "0" + a.getDate();
  }
  else{
    day = a.getDate();
  }
  return [a.getFullYear() + "", (a.getMonth() + 1) + "", day] ;
}

//判断是否为管理员
//if (!IsAdmin()){return;}
export const IsAdmin = () => {
  var admin = wx.getStorageSync("admin") || []
  if (admin.length === 0) {
    return false;
  } else {
    if (admin.isAdmin) { return true}
    else { return false}
  }
}

