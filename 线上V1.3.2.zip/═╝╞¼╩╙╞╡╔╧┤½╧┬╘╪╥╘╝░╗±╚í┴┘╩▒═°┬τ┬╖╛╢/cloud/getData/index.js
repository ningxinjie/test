// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init() 

// 云函数入口函数
exports.main = async (event, context) => {
  if (!event.filed){
    return cloud.database().collection(event.table_name).get()
  }
  else{
    return cloud.database().collection(event.table_name).orderBy(event.filed,event.order).get()
  }
}