import { CallFunction, Transformation2Time, ShowLoading, ShowModal, ShowToast,IsAdmin} from "../../utils/index.js"
Page({
 
  /**
   * 页面的初始数据
   */ 
  data: {
    content_info:[],
    content_more:[],
    animationData:{},

    //懒加载是否需要加载(与加载的列表维度保持一致)
    items_show: [],
    //懒加载个数，
    items_show_count: 6,
    //滑动屏幕目前到达的高度
    slide_height: 0,
    //滑动设置次数(因为onload改变一次因此默认为1)
    set_slide_height_count: 1,
    //当前使用手机的屏幕高度
    windowHeight: 0,
    
    //是否为管理员
    isAdmin: false,
    //用户openid
    adminOpenid: "",
  },

  //点击上传视频按钮
  navigate2videoUpload(){
    // if (!IsAdmin()) { return; }
    wx.navigateTo({
      url: '../index_videoUpload/index'
    })

  },
  //从数据库获取页面信息
  async getContent(){
    var res=await CallFunction("getData",{
      table_name:"beg_VideoUpload",
      filed:"datetime",
      order:"desc"
    });
    const { data } = res.result;
    var content_more=[];
    data.forEach(v=>{
      v.datetimetrans = Transformation2Time(v.datetime);
      content_more.push({ isShow: true, isShowMore:false})
    })
    this.setData({
      content_info:data,
      content_more
    })
    wx.hideLoading();
    wx.stopPullDownRefresh();
  },
  //点击图片跳转视频界面
  getVideoDetail(e){
    const { index } = e.currentTarget.dataset
    const { content_info}=this.data;
    wx.navigateTo({
      url: '../index_videoDetail/index',
      success: function (res) {
        // 通过eventChannel向被打开页面传送数据
        res.eventChannel.emit('acceptDataFromOpenerPage', { data: content_info[index] })
      }
    })
  },
  //点击删除 
  async deleteRecord(e){
    // if (!IsAdmin()) { return; }
    const { datetime } = e.currentTarget.dataset;
    const { index } = e.currentTarget.dataset;
    var isChooseOk=await ShowModal('','是否确认删除');
    if (isChooseOk.confirm){
      //用户点击确认删除
      ShowLoading('删除中...');
      //找到需要删除的数据源
      const { content_info } = this.data;
      var tempData = content_info[index];
      //删除数据库
      var res_delDb=await CallFunction("deleteData", {
        table_name: "beg_VideoUpload",
        datetime: { datetime: tempData.datetime }
      });
      //删除存储
      var res_delS_p =await CallFunction("deleteStorage", { fileList: [tempData.picID] });
      var res_delS_v =await CallFunction("deleteStorage", { fileList: [tempData.videoID] });
      //隐藏删除对象
      this.data.content_more[index].isShow=false;
       //因为所有循环共用一个动画，因此点击一个更多的时候，将除此之外的其他全部隐藏
      var items_show = this.detailDel_lazyLoad();
      this.setData({
        content_more: this.data.content_more,
        items_show
      })
      wx.hideLoading();

    }
  },
  //点击更多操作(省略号)
  showMore(e){
    // if (!IsAdmin()) { return; }
    const { index } = e.currentTarget.dataset;
    var { content_more } = this.data;
    var isShow = content_more[index];
    content_more.forEach((v, i) => {
      // console.log(v); console.log(i);
      if (i != index) {
        v.isShowMore = false;
      }
    }) 
    content_more[index].isShowMore = !content_more[index].isShowMore;
    this.setData({
      content_more
    })
  },
  //点击任意处将更多操作全部置为false
  closeShowMore() {
    var { content_more } = this.data;
    content_more.forEach((v, i) => {
      v.isShowMore = false;
    });
    this.setData({
      content_more
    })
  },
  //点击更多跳转至更多操作界面
  navigate2videoDetail(e){
    const { index } = e.currentTarget.dataset;
    const { content_info } = this.data;
    var data={
      videoID: content_info[index].videoID
    }
    // console.log(data);
    wx.navigateTo({
      url: '../index_videoMore/index',
      success: function (res) {
        // 通过eventChannel向被打开页面传送数据
        res.eventChannel.emit('acceptDataFromOpenerPage', data)
      }
    })
  },
  async onLoad(options) {
    ShowLoading('加载中');
    //识别身份并且判断是否为管理员
    var admin = wx.getStorageSync("admin") || [];
    if (admin.length != 0) {
      this.setData({
        adminOpenid: admin.openid,
        isAdmin: admin.isAdmin
      })
    } else {
      this.setData({
        adminOpenid: "",
        isAdmin: false
      })
    }
    await this.getContent();
    var items_show = this.initItems_show();
    var windowHeight = wx.getSystemInfoSync().windowHeight;
    this.setData({
      set_slide_height_count: 1,
      items_show,
      windowHeight,
      slide_height: 1.5 * windowHeight
    })
    wx.hideLoading();
  },
  async onShow(){
    let _this = this;
    //识别身份并且判断是否为管理员
    var admin = wx.getStorageSync("admin") || [];
    if (admin.length != 0) {
      this.setData({
        adminOpenid: admin.openid,
        isAdmin: admin.isAdmin
      })
    } else {
      this.setData({
        adminOpenid: "",
        isAdmin: false
      })
    }
    await this.getContent();
    let { windowHeight, items_show, content_info } = this.data;
    var addLength = content_info.length - items_show.length;
    //如果没变说明不是去上传图片，而是预览图片了,因此没必要做任何修改
    if(addLength!=0){
      //如果新增数量了应该在数组前方加对应的true
      for (let i = 0; i < addLength;i++) { items_show.unshift(true);}
      _this.setData({
        items_show
      })
    }
   
  },
  async onPullDownRefresh () {
    ShowLoading('拉取最新资源中');
    await this.getContent();
    const { windowHeight } = this.data;
    //这里不需要改，因为触发这个的时候用户界面在最上方，而且数据也是重新拉取的,因此相当于onload一样
    var items_show = this.initItems_show();
    this.setData({
      set_slide_height_count: 1,
      items_show,
      slide_height: 1.5 * windowHeight
    })
    wx.stopPullDownRefresh();
    ShowToast('加载完成');
    
  },
  //触底将所有显示都设置为true
  onReachBottom: function () {
    let { items_show } = this.data;
    for (let i = 0; i < items_show.length; i++) {
      items_show[i] = true;
    }
    this.setData({ items_show })
  },
  //初始化是否加载列表（目的是保持与显示内容维度一致）
  initItems_show() {
    //每次懒加载的个数
    const { items_show_count } = this.data;
    var items_show = [];
    for (let i = 0; i < this.data.content_info.length; i++) {
      if (i < items_show_count ) {
        items_show.push(true);
      }
      else {
        items_show.push(false);
      }
    }
    return items_show;
  },
  //滑动屏幕
  onPageScroll: function (res) {
    //每次懒加载的个数
    const { items_show_count } = this.data;
    //按照滚动高度，设置接下来的图片进行加载
    let count = this.data.set_slide_height_count;
    var _this = this;
    const { windowHeight } = this.data;
    //从1.5被高度开始 每次超过一次屏幕高度设置一次继续显示加载条目图片的数量
    if (res.scrollTop > (count + 0.5) * windowHeight) {
      let { items_show } = _this.data;
      for (let i = 0; i < items_show.length; i++) {
        if (i < (count + 1) * items_show_count) {
          items_show[i] = true;
        }
      }
      _this.setData({
        items_show,
        set_slide_height_count: count + 1,
        slide_height: res.scrollTop
      })
    }
  },
  //处理由于删除而造成懒加载上移可能仍然不显示的问题
  detailDel_lazyLoad() {
    //因为一次删除一个，因此我将懒加载下一个加载出来,然后就跳出循环
    let { items_show } = this.data;
    for (let i = 0; i < items_show.length; i++) {
      if (items_show[i] === false) {
        items_show[i] = true;
        return items_show;
      }
    }
    return items_show;
  }
})