import { ChooseImage, ChooseVideo, UploadforVideo, ShowLoading, dbAdd, ShowToast, CallFunction} from "../../utils/index.js"
Page({
  data: {
    //输入框的输入
    title:"",
    //封面路径生成的本地临时路径
    coverPath:"",
    //是否正在选择上传图片
    isChoosing:false,
    //视频生成的本地临时路径
    videoPath:""
  },
  //点击取消
  handleCancel(){
    wx.navigateBack({
      delta: 1
    })
  },
  //获取输入框的输入
  getTitle(e){
    this.setData({
      title:e.detail.value
    })
  },
  //选择封面
  async chooseCover(){
    var res=await ChooseImage();
    this.setData({
      coverPath:res.tempFilePaths[0]
    })
  },
  //选择视频
  async choose_Video(){
    this.setData({isChoosing:true});
    var res =await ChooseVideo();
    console.log(res);
    this.setData({ isChoosing: false, videoPath: res.tempFilePath });
  },
  //上传
  async getUserInfo(e){
    const { title, coverPath, videoPath } = this.data;
    // console.log(coverPath == ''); console.log(videoPath);return;
    if (coverPath==''){
      ShowToast('还未选择封面','none');
      return;
    } else if (videoPath == '' || videoPath==undefined){
      ShowToast('还未选择视频', 'none');
      return;
    }
    ShowLoading('上传中...');
    var userInfo = this.getOrSetStorageSync(e);
    if (userInfo==null){
      wx.hideLoading();
      return;
    }
    
    //上传视频
    var video_path = await UploadforVideo('', videoPath); console.log(video_path);
    //上传图片
    var cover_path = await UploadforVideo('pic', coverPath); console.log(cover_path);
    // 写入数据库
    this.uploadVideoAndPic(userInfo.nickName, userInfo.avatarUrl, cover_path, video_path)

    //显示上传完成并跳转回展示页面
    ShowToast("上传完成", ''); this.handleCancel();
  },
  //(读取)设置缓存并将缓存数据返回出来
  // 如果有缓存则读取，没有缓存则创建
  getOrSetStorageSync(e){
    if (!e.detail.rawData) {
      //没有获取到个人信息
      wx.showToast({
        title: '上传失败',
        icon: "none"
      });
      return null;
    }
    else {
      var userInfo = wx.getStorageSync("userInfo") || [];
      if (userInfo.length === 0) {
        var userInfo = JSON.parse(e.detail.rawData);
        var data = {
          nickName: userInfo.nickName,
          avatarUrl: userInfo.avatarUrl,
          gender: userInfo.gender, //性别 0：未知、1：男、2：女
          province: userInfo.province,
          city: userInfo.city,
          country: userInfo.country
        };
        //设置缓存并返回
        wx.setStorageSync("userInfo", data);
        //获取用户是否为管理员
        this.checkAdmin();
        return userInfo;
      }
      else {
        //获取缓存中的数据进返回
        return userInfo;
      }
    }
  },
  //检查是否为管理员
  async checkAdmin() {
    let _this = this;
    var datetime = new Date().getTime();
    //插入数据到beg_check_openid
    dbAdd("beg_check_openid", { datetime: datetime });
    //获取刚刚插入的数据
    var res = await CallFunction("getDataByFiled", {
      table_name: "beg_check_openid",
      filed: { datetime: datetime }
    });
    var openid = res.result.data[0]._openid;

    //获取管理者列表
    var res1 = await CallFunction("getData", {
      table_name: "beg_admin"
    });
    var arrAdmin = [];
    res1.result.data.forEach(v => { arrAdmin.push(v.openid) })
    // console.log(arrAdmin);
    //将刚刚插入的数据删掉
    await CallFunction("deleteData", {
      table_name: "beg_check_openid",
      datetime: { datetime: datetime }
    });
    if (arrAdmin.indexOf(openid) != -1) {
      //验证成功
      wx.setStorageSync('admin', { isAdmin: true, openid: openid });
    }
    else {
      //不是管理员
      wx.setStorageSync('admin', { isAdmin: false, openid: openid });
    }
  },
  //上传--上传图片与视频
  uploadVideoAndPic(nickName, avatarUrl, coverPath, videoPath){
    let that = this;
    var date = new Date().getTime();
    var data={
      remark: that.data.title,
      name: nickName,
      headURL: avatarUrl,
      datetime: date,
      picID: coverPath,
      videoID: videoPath
    }
    // console.log(data);
    this.MyuploadFile("beg_VideoUpload",data)
  },
  //上传---上传
   MyuploadFile(table_name,params){
    dbAdd(table_name, params);
    // console.log(res);
    wx.hideLoading();
  }
 
})