import { ShowLoading, ShowToast} from '../../utils/index.js'
// pages/index_videoMore/index.js
Page({
  data: {
    videoID:"",
    isComplete:false,
    netLink:""
  },

  onLoad: function (options) {
    let _this=this;
    const eventChannel = this.getOpenerEventChannel();
    // 监听acceptDataFromOpenerPage事件，获取上一页面通过eventChannel传送到当前页面的数据
    eventChannel.on('acceptDataFromOpenerPage', function (data) {
      _this.setData({videoID: data.videoID})
    })
  },
  //视频加载可播放
  videoLoadComplete(){
    this.setData({ isComplete:true})
  },
  //复制链接
  copy(){
    const { netLink } = this.data;
    wx.setClipboardData({
      data: netLink,
    })
  },
  //生成临时路径
  getTempPath(e) {
    let that = this;
    let { videoID } = this.data;
    wx.cloud.getTempFileURL({
      fileList: [{
        fileID: videoID,
        maxAge: 60 * 60, // one hour
      }]
    }).then(res => {
      // get temp file URL
      console.log(res.fileList);
      const { tempFileURL } = res.fileList[0];
      console.log("tempFileURL", tempFileURL);
      that.setData({
        netLink: tempFileURL
      })
    }).catch(error => {
      // handle error
    })
  },

  //保存到手机
  save2Phone(e) {
    let that = this;
    let { videoID } = this.data;
    ShowLoading('正在保存...');
    wx.getSetting({
      success(res) {
        // console.log(res.authSetting)
        if (res.authSetting["scope.writePhotosAlbum"] === false) {
          wx.openSetting({})
        }
      },
      fail: err => {
        ShowToast("获取权限时出现问题", 'none')
        wx.hideLoading();
      }
    })
    //获取临时路径
    wx.cloud.getTempFileURL({
      fileList: [videoID],
      success: res0 => {
        // get temp file URL

        wx.downloadFile({
          url: res0.fileList[0].tempFileURL, //仅为示例，并非真实的资源
          success(res) {
            // console.log(res);
            // 只要服务器有响应数据，就会把响应内容写入文件并进入 success 回调，业务需要自行判断是否下载到了想要的内容
            if (res.statusCode === 200) {
              that.SaveVideoToPhotosAlbum(res.tempFilePath);
            }
            else {
              ShowToast("请求下载资源时失败");
              wx.hideLoading();
            }
          },
          fail(err) {
            console.log(err);
            ShowToast("请求下载资源时失败");
            wx.hideLoading();
          }
        })
      },
      fail: err => {
        ShowToast("生成临时路径时出错");
        wx.hideLoading();
      }
    })
  },

  //保存图片到手机(需要代码)
  SaveVideoToPhotosAlbum(filePath) {
    wx.saveVideoToPhotosAlbum({
      filePath: filePath,
      success(res) { console.log(res); ShowToast("保存成功", '') },
      fail(err) { console.log(err); ShowToast("保存失败", 'none') },
      complete() { wx.hideLoading(); }
    })
  },

})