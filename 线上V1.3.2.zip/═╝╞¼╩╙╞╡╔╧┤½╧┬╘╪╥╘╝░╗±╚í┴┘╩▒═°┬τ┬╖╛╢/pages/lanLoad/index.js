// pages/lanLoad/index.js
Page({


  data: {
    damoHeight:200,
    imgs:[],
    arr:[]
  },

  
  onLoad: function (options) {
    //图片列表
    var arr = ["cloud://nxj-huayuan.6e78-nxj-huayuan-1258263530/cherry/1581820599433.jpg","cloud://nxj-huayuan.6e78-nxj-huayuan-1258263530/cherry/1581820629299.jpg"];
    var arr1=[];
    var arr2 = [];
    for(let i=0;i<20;i++){
      for (let j = 0; j < 2; j++) {
        arr1.push(arr[j])
        arr2.push(false)
      }
    }
    this.setData({
      imgs: arr1,
      arr: arr2
    })

    //设置本也可见的图片加载
    let _this = this;
    let num = Math.ceil(wx.getSystemInfoSync().windowHeight / 300);
    for (let i = 0; i < num; i++) {
      _this.data.arr[i] = true;
    };
    this.setData({
      arr: _this.data.arr
    })
  },
  onPageScroll: function (res) {
    //按照滚动高度，设置接下来的图片进行加载
    var _this = this;
    var str = parseInt(res.scrollTop / _this.data.damoHeight);
    if (str>this.data.imgs.length-1){
      return
    }
    //这样写不动原数组，只是对其中前方进行修改 厉害！ 记住！
    _this.data.arr[str] = true;
    _this.setData({
      arr: _this.data.arr
    })
  },

})