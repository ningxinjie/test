import { CallFunction, ShowToast, ShowLoading} from "../../utils/index.js"
// pages/index_picDetail/index.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    imgs:[],
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var arrFileID = options.fileID.split(',');
    // console.log(arrFileID);
    var imgs=[];
    arrFileID.forEach((v,i)=>{
      imgs.push({
        id:i,
        fileID:v,
        netLink:""
      })
    })
    this.setData({
      imgs
    })
  },

  //点击复制链接
  copy(e){
    const { index } = e.currentTarget.dataset;
    const { imgs } = this.data;
    wx.setClipboardData({
      data: imgs[index].netLink,
      // success(res) {
      //   wx.getClipboardData({
      //     success(res) {
      //       console.log(res.data) // data
      //     }
      //   })
      // }
    })
  },
  //生成临时路径
  getTempPath(e){
    let that=this;
    let {imgs}=this.data;
    const {fileid}= e.currentTarget.dataset;
    const { index } = e.currentTarget.dataset;
      wx.cloud.getTempFileURL({
        fileList: [{
          fileID: fileid,
          maxAge: 60 * 60, // one hour
        }]
      }).then(res => {
        // get temp file URL
        console.log(res.fileList);
        const { tempFileURL } = res.fileList[0];
        imgs[index].netLink = tempFileURL;
        console.log("tempFileURL", tempFileURL);
        that.setData({
          imgs
        })
      }).catch(error => {
        // handle error
      })
  },
  //保存到手机
  save2Phone(e){
    let that=this;
    const { fileid } = e.currentTarget.dataset;
    ShowLoading('正在保存...');
    wx.getSetting({
      success(res) {
        if ( res.authSetting["scope.writePhotosAlbum"]===false){
          wx.openSetting({ })
        }
      },
      fail:err=>{
        ShowToast("获取权限时出现问题",'none')
        wx.hideLoading();
      }
    })
    //获取临时路径
    wx.cloud.getTempFileURL({
      fileList: [fileid],
      success: res0 => {
        // get temp file URL
        
        wx.downloadFile({
          url: res0.fileList[0].tempFileURL, //仅为示例，并非真实的资源
          success(res) {
            // console.log(res);
            // 只要服务器有响应数据，就会把响应内容写入文件并进入 success 回调，业务需要自行判断是否下载到了想要的内容
            if (res.statusCode === 200) {
              that.SaveImageToPhotosAlbum(res.tempFilePath);
            }
            else {
              ShowToast("请求下载资源时失败");
              wx.hideLoading();
            }
          },
          fail(err) {
            console.log(err);
            ShowToast("请求下载资源时失败");
            wx.hideLoading();
          }
        })
      },
      fail: err => {
        ShowToast("生成临时路径时出错");
        wx.hideLoading();
      }
    }) 
  },

  //保存图片到手机(需要代码)
  SaveImageToPhotosAlbum(filePath){
    wx.saveImageToPhotosAlbum({
      filePath: filePath,
      success(res) { console.log(res); ShowToast("保存成功", '') },
      fail(err) { console.log(err); ShowToast("保存失败", 'none') },
      complete(){wx.hideLoading();}
    })
  },
  //点击图片放大
  biggerImg(e){
    ShowLoading('');
    const {fileid}= e.currentTarget.dataset;
    var urls=[];
    const { imgs}=this.data;
    imgs.forEach(v=>{
      urls.push(v.fileID)
    });
    wx.previewImage({
      current: fileid, // 当前显示图片的http链接
      urls: urls, // 需要预览的图片http链接列表
      success:res=>{wx.hideLoading();}
    })
  }
})