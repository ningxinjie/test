import { CallFunction, ShowToast, ShowLoading} from '../../utils/index.js'
Page({

  /**
   * 页面的初始数据
   */
  data: {
    oldtitle:"",
    newtitle:""
  },
  //获取输入框的输入
  getValue(e){
    const {value}=e.detail;
    this.setData({
      newtitle: value
    })
  },
  async onShow(){
    let _this=this;
    var res = await CallFunction("getDataByFiled", {
      table_name: "beg_swiper",
      filed: { _id: "001" }
    })
    this.setData({
      oldtitle:res.result.data[0].title
    })
  },
  //确认修改
  async confirmModify(){
    const { newtitle}=this.data;
    if (newtitle===''){
      ShowToast("请输入修改后的标题",'none');
      return;
    }
    ShowLoading("修改中");
    var res = await CallFunction("updateDataByFiled",{
      table_name: "beg_swiper",
      filed: { _id: "001"},
      updateData: { title: newtitle}
    })
    wx.hideLoading();
    wx.navigateBack({})

  }


})