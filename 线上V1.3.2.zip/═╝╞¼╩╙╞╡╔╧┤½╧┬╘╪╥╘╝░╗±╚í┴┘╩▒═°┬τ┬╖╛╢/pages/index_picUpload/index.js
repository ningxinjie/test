import { UploadFile, ShowToastLoading, ShowLoading, CallFunction, ShowToast, dbAdd} from "../../utils/index.js"
// pages/index_picUpload/index.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    //上传图片的备注
    imgsRemark:"",
    //未上传图片列表
    imgNotUploadList:[],
  },
  //获取用户信息(上传在此实现)
 async getUserInfo(e){
    //用户点击拒绝获取个人信息
    if(!e.detail.rawData){
      wx.showToast({
        title: '上传失败',
        icon:"none"
      });

    }
    else{
      var userInfo = wx.getStorageSync("userInfo")||[];
      // console.log(userInfo);
      //没有获取到该缓存
      if (userInfo.length===0){
        // console.log("000");
        var userInfo = JSON.parse(e.detail.rawData);
        var data = {
          nickName: userInfo.nickName,
          avatarUrl: userInfo.avatarUrl,
          gender: userInfo.gender, //性别 0：未知、1：男、2：女
          province: userInfo.province,
          city: userInfo.city,
          country: userInfo.country
        };
        // console.log(userInfo);
        // console.log(data);
        //设置缓存并完成上传操作
        wx.setStorageSync("userInfo", data);
        await this.checkAdmin();
        this.uploadPics(userInfo.nickName, userInfo.avatarUrl)
      }
      else{
        //获取到缓存完成上传操作
        this.uploadPics(userInfo.nickName, userInfo.avatarUrl)
      }
    }
  },

  //检查是否为管理员
  async checkAdmin() {
    ShowLoading("验证身份中...");
    let _this = this;
    var datetime = new Date().getTime();
    //插入数据到beg_check_openid
    dbAdd("beg_check_openid", { datetime: datetime });
    //获取刚刚插入的数据
    var res = await CallFunction("getDataByFiled", {
      table_name: "beg_check_openid",
      filed: { datetime: datetime }
    });
    var openid = res.result.data[0]._openid;

    //获取管理者列表
    var res1 = await CallFunction("getData", {
      table_name: "beg_admin"
    });
    var arrAdmin = [];
    res1.result.data.forEach(v => { arrAdmin.push(v.openid) })
    // console.log(arrAdmin);
    //将刚刚插入的数据删掉
    await CallFunction("deleteData", {
      table_name: "beg_check_openid",
      datetime: { datetime: datetime }
    });
    if (arrAdmin.indexOf(openid) != -1) {
      //验证成功
      wx.setStorageSync("admin", { isAdmin: true, openid: openid });
      wx.hideLoading();
    } 
    else {
      //不是管理员
      wx.setStorageSync("admin", { isAdmin: false, openid: openid });
      wx.hideLoading();
    }
  },

  //防止还未传输完成，就点击下一次上传
  uploadComplete: true,
  //上传操作
  uploadPics(name, headURL){
    let that=this;
    const { imgsRemark } = this.data;//备注
    if (!this.uploadComplete) {
      wx.showToast({
        title: '本次上传还未完成！',
      })
      return;
    }
    var date = new Date().getTime();
    this.uploadComplete = false;
    this.MyuploadFile({
      remark: that.data.imgsRemark,
      name: name,
      headURL: headURL,
      datetime: date
    })
  },
  //选择图片
  choosePics() {
    wx.chooseImage({
      count: 9,
      sizeType: ['original', 'compressed'],
      sourceType: ['album', 'camera'],
      success: (result) => {
        console.log(result);
        let imgNotUploadListBefor = this.data.imgNotUploadList;
        for (let i = 0; i < result.tempFilePaths.length; i++) {
          imgNotUploadListBefor.push({
            "tempFilePaths": result.tempFilePaths[i],
            "isShow": true
          });
        }
        this.setData({
          imgNotUploadList: imgNotUploadListBefor
        })
      },
      fail: () => { },
      complete: () => { }
    });
  },
  //监听textare输入内容事件
  getRemark(e) {
    const { value } = e.detail;
    this.setData({
      imgsRemark: value
    })
  },
  //点击图像叉删除
  closeCeshi(e) {
    const { index } = e.currentTarget.dataset;
    let tempList = this.data.imgNotUploadList;
    tempList[index].isShow = false;
    this.setData({
      imgNotUploadList: tempList
    })
  },
  //预览已选择的图片
  biggerImg(e) {
    const { tempFilePaths } = e.currentTarget.dataset.src;
    let tempList = [];
    const { imgNotUploadList } = this.data;
    for (let i = 0; i < imgNotUploadList.length; i++) {
      if (imgNotUploadList[i].isShow == true) {
        tempList.push(imgNotUploadList[i].tempFilePaths)
      }
    }
    wx.previewImage({
      current: tempFilePaths, // 当前显示图片的http链接
      urls: tempList, // 需要预览的图片http链接列表
      success(res) { console.log(res) },
      fail(err) { console.log(err) }
    })
  },
  //点击取消
  handleCancel(){
    wx.navigateBack({
      delta: 1,
    })
  },
  //上传
  MyuploadFile(params) {
    console.log(params)
    let that = this;
    const { imgNotUploadList } = this.data;
    let tempImgList = [];
    imgNotUploadList.forEach(v => {
      if (v.isShow == true) {
        tempImgList.push(v);
      }
    })

    if (tempImgList.length == 0) {
      wx - wx.showToast({
        title: '您还未选择图片',
        icon: 'none',
        mask: true,
      })
      that.uploadComplete = true;
      return;
    }
    var count = tempImgList.length;
    ShowToastLoading("正在上传1/" + count);
    let completeCount = 0;
    for (let i = 0; i < count; i++) {
      UploadFile({ cloudPath: "beg/imgs/" + new Date().getTime() + "_" + Math.ceil(Math.random() * 100) + ".jpg" },
        { filePath: tempImgList[i].tempFilePaths }).then(res1 => {
          console.log(res1);
          wx.cloud.database().collection("beg_PicUpload").add({
            data: {
              ...params,
              fileID: res1.fileID
            },
            success: res1 => {
              if(i+2<=count){
                ShowToastLoading("已完成" + completeCount + "/" + count);
              }
            },
            complete: comp1 => {
              completeCount++;
              if (completeCount === tempImgList.length) {
                that.uploadComplete = true;
                wx.showToast({
                  title: '上传完成',
                })
                that.setData({
                  imgsRemark: "",
                  imgNotUploadList:[]
                });
                wx.navigateBack({
                  delta: 1,
                })
              }
            }
          })
        })
    }
  },

 
 
})