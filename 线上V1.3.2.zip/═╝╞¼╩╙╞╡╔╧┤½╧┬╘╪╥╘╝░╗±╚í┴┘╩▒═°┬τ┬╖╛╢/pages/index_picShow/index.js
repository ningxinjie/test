import { ShowModal, ShowToast, CallFunction, ShowLoading,IsAdmin} from "../../utils/index.js"
Page({
  data:{
    today_title:"",
    swiperImgs:[],
    //与swiperImgs维度一致
    isSwiperImgsComplete:[],
    //内容区
    content_info:[],
    //与内容区对应的是否显示
    content_more:[],
    //点击更多的动画效果
    animationData:{},
    //懒加载是否需要加载(与加载的列表维度保持一致)
    items_show:[],
    //懒加载个数，
    items_show_count:6,
    //滑动屏幕目前到达的高度 
    slide_height:0,
    //滑动设置次数(因为onload改变一次因此默认为1)
    set_slide_height_count:1,
    //当前使用手机的屏幕高度
    windowHeight:0,
     
    //是否为管理员
    isAdmin:false,
    //用户openid
    adminOpenid:"",
  },
  //跳转视频上传界面
  navigate2picUpload(){
    wx.navigateTo({
      url: '../index_picUpload/index',
    })
  },
  //下拉刷新最新数据
  async onPullDownRefresh() {
    ShowLoading('加载中');
    await this.getSwiperData();
    await this.getContentData();
    const { windowHeight } = this.data;
    //这里不需要改，因为触发这个的时候用户界面在最上方，而且数据也是重新拉取的,因此相当于onload一样
    var items_show = this.initItems_show();
    this.setData({
      set_slide_height_count: 1,
      items_show,
      slide_height: 1.5 * windowHeight
    })
    wx.stopPullDownRefresh();
    ShowToast('加载完成','')
  },
  //转成时间
  transformation2Time(dateNum){
    var a = new Date(dateNum);
    return a.getFullYear() + "-" + (a.getMonth() + 1) + "-" + a.getDate() + "     " + a.getHours() + ":" + a.getMinutes() + ":" + a.getSeconds()
  },
  //获取轮播及标题数据
  getSwiperData(str){
    let that=this;
    wx.cloud.callFunction({
      name: "getData",
      data: {
        table_name: "beg_swiper"
      }
    }).then(res => {
      // console.log(res);
      const {data} = res.result;
      // console.log(data);
      var title="";
      var imgs=[];
      var tempIsComplete=[];
      data.forEach(v => { 
        if (v._id == "001"){
          title = v.title
        } 
        else{
          imgs.push(v.fileID);
          tempIsComplete.push(false);
        }})
        //如果onload的时候，那么我设置加载，否则轮播图不设置加载，因为默认好像已经加载完了
      if (str==="onload"){
        that.setData({
          today_title: title,
          swiperImgs: imgs,
          isSwiperImgsComplete: tempIsComplete
        })
      }
      else{
        that.setData({
          today_title: title,
          swiperImgs: imgs
        })
      }

    })

  },
  //检查每个轮播图是否加载完成
  checkComplete(e){
    const {index}=e.currentTarget.dataset;
    this.data.isSwiperImgsComplete[index]=true;
    this.setData({
      isSwiperImgsComplete: this.data.isSwiperImgsComplete
    })
  },
  //获取内容区数据
  async getContentData(){
    let that = this;
    await wx.cloud.callFunction({
      name: "getData",
      data: {
        table_name: "beg_PicUpload",
        filed:"datetime",
        order:"desc"
      }
    }).then(res => {
      const {data}=res.result;
      // a.sort((a,b)=>{a.datetime<b.datetime?-1:1})
      // console.log(data);
     
      data.forEach(v => v.date = that.transformation2Time(v.datetime));
      var content_info=this.groupArrByFiled(data,"datetime");
      // content_info.forEach(v=>v.top=100)
      // console.log("content_info", content_info);
      //是否显示与内容区保持一致
      var content_more=[];
      for (let i = 0; i < content_info.length;i++){
        content_more.push({
          isShowMore: false,//针对于更多功能的展示
          isShow:true//针对于删除
        })
      }
      that.setData({
        content_info,
        content_more
      })
    })
  },
  //按照某字段将数组进行分组
  groupArrByFiled(arr,filed){
    var map = {}, content_info = [];
    for (var i = 0; i < arr.length; i++){
      if (!map[arr[i][filed]]){
        content_info.push({
          datetime:arr[i].datetime,
          headURL: arr[i].headURL,
          name: arr[i].name,
          remark: arr[i].remark,
          date: arr[i].date,
          openid:arr[i]._openid,
          data:[{
            datetime: arr[i].datetime,
            fileID: arr[i].fileID,
            headURL: arr[i].headURL,
            name: arr[i].name,
            remark: arr[i].remark,
            _id: arr[i]._id,
            _openid: arr[i]._openid,
            }]
        })
        map[arr[i][filed]] = arr[i];
      }
      else{
        for(var j = 0; j < content_info.length; j++){
          var ci = content_info[j];
          if (ci.datetime == arr[i].datetime){
              ci.data.push(arr[i]);
              break;
            }
        }
      }
    }
    return content_info;
  }, 
  //点击图片进行放大
  biggerImg(e){
    const { index } = e.currentTarget.dataset;
    if (!this.data.isAdmin){
      if (this.data.content_info[index].openid != this.data.adminOpenid) {
        ShowToast('您无权放大查看非本人发布的照片', 'none');
        return;
      }
    }
    ShowLoading('')
    const {fileid}=e.currentTarget.dataset;
   
    const {content_info}=this.data;
    var tempUrls=[];
    content_info[index].data.forEach(v => tempUrls.push(v.fileID));
    // console.log(fileid, index);
    wx.previewImage({
      current: fileid , // 当前显示图片的http链接
      urls: tempUrls, // 需要预览的图片http链接列表
      success: res => { wx.hideLoading();}
    })
  },
  //点击展开更多操作
  showMore(e){
    const {index} = e.currentTarget.dataset;
    var {content_more}=this.data;
    var isShow=content_more[index];
    //因为所有循环共用一个动画，因此点击一个更多的时候，将除此之外的其他全部隐藏
    content_more.forEach((v,i)=>{
      // console.log(v); console.log(i);
      if (i != index){
        v.isShowMore=false;
      }
    })
    //创建动画
    var animation = wx.createAnimation({
      timingFunction: "ease"
    })
    content_more[index].isShowMore = !content_more[index].isShowMore;
    this.setData({
      content_more
    })
    if (!isShow){
      animation.opacity(0).step();
    }
    else{
      animation.opacity(1).step();
    }
    
    this.setData({
      animationData: animation.export()
    })

  },
  //点击任意处将更多操作全部置为false
  closeShowMore() {
    var { content_more } = this.data;
    content_more.forEach((v, i) => {
        v.isShowMore = false;
    });
    this.setData({
      content_more
    })

  },
  //点击删除
  delete(e){ 
    let that=this;
    //datetime作为每项的唯一标识，使用它来查找
    const {datetime}=e.currentTarget.dataset;
    const { index } = e.currentTarget.dataset;
    ShowModal('','是否确认删除').then(res=>{
      // console.log(res);
      if (res.confirm){
        ShowLoading('删除中...')
        //点击确认
        //找到相应的数据
        const {content_info}=this.data;
        var tempData={};
        content_info.forEach(v => {
          if (v.datetime == datetime){
              tempData=v;
            }
          })
        // console.log(tempData);
        let completeCount=0;
        //删除数据库
        CallFunction("deleteData", {
          table_name: "beg_PicUpload",
          datetime: {datetime:tempData.datetime}
        }).then(res1 => { 
            // console.log(res1) 
            completeCount++;
           })
        //删除存储
        tempData.data.forEach(v => {
          CallFunction("deleteStorage", { fileList: [v.fileID] }).then(res1 => {
            completeCount++;
          })
        })

        var timer = setInterval(function () {
          // console.log(completeCount);
          //图片数量和这一整条记录，全部删除
          if (completeCount == tempData.data.length+1) {
            wx.hideLoading();
            ShowToast("删除成功", '');
            var {content_more} = that.data;
            content_more[index].isShow=false;
            //因为删除了，所以下面的懒加载还未加载的可能要上来了，在这里我需要处理一下
            var items_show = that.detailDel_lazyLoad();
            that.setData({
              content_more,
              items_show
            })
            clearInterval(timer);
          }
        }, 300)
        
      }
    });
  },
  /*
    显示3个，拖到一定高度，再显示下3个，直到最后
   */
  async onLoad(options){
    let _this=this;
    ShowLoading('加载中');
    //识别身份并且判断是否为管理员
    var admin=wx.getStorageSync("admin")||[];
    if (admin.length!=0){
      this.setData({
        adminOpenid: admin.openid,
        isAdmin: admin.isAdmin
      })
    }else{
      this.setData({
        adminOpenid: "",
        isAdmin: false
      })
    }
    await this.getSwiperData("onload");
    await this.getContentData();
    var items_show = this.initItems_show();
    var windowHeight = wx.getSystemInfoSync().windowHeight;
    this.setData({
      set_slide_height_count:1,
      items_show,
      windowHeight,
      slide_height: 1.5 * windowHeight
    })
    wx.hideLoading();
  },
  //滑动屏幕
  onPageScroll: function (res) {  
    //每次懒加载的个数
    const { items_show_count } = this.data;
    //按照滚动高度，设置接下来的图片进行加载
    let count=this.data.set_slide_height_count;
    var _this = this;
    const { windowHeight}=this.data;
    //从1.5被高度开始 每次超过一次屏幕高度设置一次继续显示加载条目图片的数量
    if (res.scrollTop > (count+0.5) * windowHeight){
      let { items_show } = _this.data;
      for (let i = 0; i < items_show.length;i++){
        if (i < (count + 1) * items_show_count) {
          items_show[i] = true;
        }
      }
      _this.setData({
        items_show,
        set_slide_height_count:count+1,
        slide_height: res.scrollTop
      })
    }
  },
  //初始化是否加载列表（目的是保持与显示内容维度一致）
  initItems_show(){
    //每次懒加载的个数
    const { items_show_count} = this.data;
    var items_show = [];
    for (let i = 0; i < this.data.content_info.length; i++) {
      if (i < items_show_count ) {
        items_show.push(true);
      }
      else {
        items_show.push(false);
      }
    }
    return items_show;
  },
  async onShow(){
    let _this=this;
    //识别身份并且判断是否为管理员
    var admin = wx.getStorageSync("admin") || [];
    if (admin.length != 0) {
      this.setData({
        adminOpenid: admin.openid,
        isAdmin: admin.isAdmin
      })
    } else {
      this.setData({
        adminOpenid: "",
        isAdmin: false
      })
    }
    //跳转回来的时候刷新这里
    await this.getContentData();
    const { windowHeight, items_show,content_info}=this.data;
    var addLength = content_info.length - items_show.length;
     //如果没变说明不是去上传图片，而是预览图片了,因此没必要做任何修改
    if (addLength!=0){
      //如果新增数量了应该在数组前方加对应的true
      for (let i = 0; i < addLength; i++) { items_show.unshift(true); }
      _this.setData({
        items_show
      })
     }
    
  },
  //触底将所有显示都设置为true
  onReachBottom(){
    let { items_show}=this.data;
    for (let i = 0; i < items_show.length; i++) {
      items_show[i]=true;
    }
    this.setData({ items_show})
  },
  //点击更多操作
  navigate2picDetail(e){
    const { datetime } = e.currentTarget.dataset;
    const { content_info } = this.data;
    var tempData = [];
    content_info.forEach(v => {
      if (v.datetime == datetime) {
        v.data.forEach(v1=>{
          tempData.push(v1.fileID)
        })
      }
    })
    // console.log(tempData);
    wx.navigateTo({
      url: '../index_picDetail/index?fileID=' + tempData,
    })
  },
  //处理由于删除而造成懒加载上移可能仍然不显示的问题
  detailDel_lazyLoad() {
    //因为一次删除一个，因此我将懒加载下一个加载出来,然后就跳出循环
    let { items_show } = this.data;
    for (let i = 0; i < items_show.length; i++) {
      if (items_show[i]=== false) {
        items_show[i] = true;
        return items_show;
      }
    }
    return items_show;
  },
})