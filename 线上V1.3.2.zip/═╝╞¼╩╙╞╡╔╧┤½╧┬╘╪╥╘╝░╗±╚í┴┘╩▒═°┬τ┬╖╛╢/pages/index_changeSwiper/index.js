import { CallFunction, ShowLoading, ShowToast, ChooseImage, UploadFile,dbAdd} from '../../utils/index.js'
Page({
  data: {
    //轮播图
    swiperImages:[],
    //轮播图对应的id，为了删除的时候好删除
    swiperImagesID:[],
    //预览的图片
    previewImg:"",

  },
  async onLoad(){
    var res=await CallFunction("getData",{
      table_name:"beg_swiper"
    });
    var tempData=[];
    var tempDataID = [];
    res.result.data.forEach(v=>{
      if (v._id != '001') { tempData.push(v.fileID); tempDataID.push(v._id); }
    })
    this.setData({
      swiperImages: tempData,
      swiperImagesID: tempDataID
    })
  },
  //预览图片
  previewImg(e){
    const { swiperImages}=this.data;
    const {index}=e.currentTarget.dataset;
    this.setData({
      previewImg: swiperImages[index]
    })
  },
  //删除
  async deleteRecord(e){
    const { swiperImagesID} = this.data;
    const { index } = e.currentTarget.dataset;
    ShowLoading("删除中...");
    var res = await CallFunction("deleteData",{
      table_name:"beg_swiper",
      datetime: { _id: swiperImagesID[index]}
    })
    this.data.swiperImages.splice(index,1);
    this.setData({

      swiperImages: this.data.swiperImages
    })
    wx.hideLoading();
  },
  //上传；轮播图
  async uploadSwiperPic(){
    var res= await ChooseImage();
    ShowLoading("上传中");
    //  console.log(res);
    //上传到云存储
    var res1= await UploadFile({ cloudPath: "beg/" + new Date().getTime() + "_" + Math.ceil(Math.random() * 100) + ".jpg" },
        { filePath: res.tempFilePaths[0] })
    // console.log(res1);
    var fileID = res1.fileID;
    //传入数据库
    var res2 = await dbAdd("beg_swiper", { fileID: fileID});
    // console.log(res2);
    var _id = res2._id;
    this.data.swiperImages.push(fileID);
    this.data.swiperImagesID.push(_id);
    this.setData({
      swiperImages: this.data.swiperImages,
      swiperImagesID: this.data.swiperImagesID
    })
    ShowToast("上传完成");
  }
 
})