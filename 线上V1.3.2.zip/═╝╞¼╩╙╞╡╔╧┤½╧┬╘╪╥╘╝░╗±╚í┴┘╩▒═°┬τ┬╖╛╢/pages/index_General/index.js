// pages/index_General/index.js
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },
  //清除缓存
  clearStroage() {
    wx.clearStorage({
      success(res){wx.showToast({
        title: '成功',
      })},
      fail(err){
        wx.showToast({
          title: '失败',
          icon:'none'
        })
      }
    })
  },


})