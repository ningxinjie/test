import { ShowLoading, ShowToast, dbAdd, CallFunction, IsAdmin} from '../../utils/index.js'
// pages/Mask/index.js
/*
onload与onshow的时候也需要判别是否存在管理员的缓存了
 */
Page({
  data: {
    //是否登录
    isLogin:false,
    userInfo:{},
    //是否为管理员
    isAdmin:false
  },

  onShow: function () {
    //判断是否登录
    var userInfo=wx.getStorageSync("userInfo")||[]
    if (userInfo.length == 0){
      //没有登录
      this.setData({ isLogin: false, isAdmin:false})
    }
    else{
      this.setData({
        userInfo,
        isLogin:true
      })
      //已经登录，判断是否为管理员
      this.checkIsAdmin();
    }
  },
  //判断是否为管理员
  checkIsAdmin(){
    var isAdmin = IsAdmin();
    if (isAdmin){
      this.setData({
        isAdmin: true 
      })
    }
  },
  //点击登录
  getUserInfo(e){
    if (e.detail.rawData){
      ShowLoading('正在登录');
      var userInfo = JSON.parse(e.detail.rawData);
      var data = {
        nickName: userInfo.nickName,
        avatarUrl: userInfo.avatarUrl,
        gender: userInfo.gender, //性别 0：未知、1：男、2：女
        province: userInfo.province,
        city: userInfo.city,
        country: userInfo.country
      };
      wx.setStorageSync("userInfo", data);
      // ShowToast('登陆成功');
      this.setData({
        userInfo,
        isLogin: true
      })
      this.checkAdmin();
    }
  },
  //全部视频 
  getAllVideo(){
    var userInfo = wx.getStorageSync("userInfo") || [];
    var admin = wx.getStorageSync("admin") || [];
    if (userInfo.length==0){
      ShowToast('您还未登录','none')
      return;
    } else if (admin.length == 0) {
      ShowToast('验证身份出现异常', 'none')
      return;
    }
    
    wx.navigateTo({
      url: '../index_MyAllVideo/index',
    })
  },

  //全部图片
  getAllPic() {
    var userInfo = wx.getStorageSync("userInfo") || [];
    var admin = wx.getStorageSync("admin") || [];
    if (userInfo.length == 0) {
      ShowToast('您还未登录', 'none')
      return;
    } else if (admin.length==0){
      ShowToast('验证身份出现异常', 'none')
      return;
    }

    wx.navigateTo({
      url: '../index_MyAllPic/index',
    })
  },

  //检查是否为管理员
  async checkAdmin(){
    ShowLoading("验证身份中...");
    let _this = this;
    var datetime = new Date().getTime();
    //插入数据到beg_check_openid
    dbAdd("beg_check_openid", { datetime: datetime});
    //获取刚刚插入的数据
    var res=await CallFunction("getDataByFiled",{
      table_name: "beg_check_openid",
      filed: { datetime: datetime}
    });
    console.log(res);
    var openid=res.result.data[0]._openid;

    //获取管理者列表
    var res1 = await CallFunction("getData", {
      table_name: "beg_admin"
    });
    var arrAdmin=[];
    res1.result.data.forEach(v => { arrAdmin.push(v.openid)})
    // console.log(arrAdmin);
    //将刚刚插入的数据删掉
    await CallFunction("deleteData", {
      table_name: "beg_check_openid",
      datetime: { datetime: datetime }
    });
    if (arrAdmin.indexOf(openid)!=-1){
      //验证成功
      _this.setData({
        isAdmin: true
      })
      wx.setStorageSync('admin', { isAdmin: true, openid: openid });
      ShowToast("验证成功");
    }
    else{
      //不是管理员
      _this.setData({
        isAdmin: false
      })
      wx.setStorageSync('admin', { isAdmin: false, openid: openid });
      ShowToast("您不是管理员",'none')
    }
  },
 
})