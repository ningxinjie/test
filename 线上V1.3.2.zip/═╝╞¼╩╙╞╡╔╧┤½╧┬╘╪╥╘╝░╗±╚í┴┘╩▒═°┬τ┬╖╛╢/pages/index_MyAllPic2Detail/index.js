// pages/index_MyAllPic2Detail/index.js
import { ShowLoading} from '../../utils/index.js'
Page({
  data: {
    data:{},
    //对于各个图片是否加载完成
    isCompletes:[]
  },

  onLoad: function (options) {
    let _this=this;
    const eventChannel = this.getOpenerEventChannel();
    // 监听acceptDataFromOpenerPage事件，获取上一页面通过eventChannel传送到当前页面的数据
    eventChannel.on('acceptDataFromOpenerPage', function (data) {
      var isCompletes=[];
      for (let i = 0; i < data.transData.fileID.length;i++){
        isCompletes.push(false);
      }
      _this.setData({
        data: data.transData,
        isCompletes
      })
    })
  },
  //当前图片是否加载完成
  checkComplete(e){
    const {index}=e.currentTarget.dataset;
    this.data.isCompletes[index]=true;
    this.setData({
      isCompletes: this.data.isCompletes
    })
  },
  //点击查看大图
  biggerImg(e){
    ShowLoading('加载中');
    const { fileid } = e.currentTarget.dataset; 
    const { data}=this.data
    wx.previewImage({
      current: fileid, // 当前显示图片的http链接
      urls: data.fileID, // 需要预览的图片http链接列表
      success: res => { wx.hideLoading(); }
    })
  }

})