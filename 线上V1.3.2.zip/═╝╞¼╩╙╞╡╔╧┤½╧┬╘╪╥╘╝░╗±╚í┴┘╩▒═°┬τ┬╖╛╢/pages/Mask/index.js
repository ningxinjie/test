// pages/index_upload/index.js
Page({
  /**
   * 页面的初始数据
   */
  data: {
    isHidden:true,
    animationData: {}
  },
  //弹出自定义询问框
  c1: false,//防止动画还未执行完就点击下一次
  ce(){

    if (this.c1==true) {
      return;
    }
    this.c1=true;
    var animation = wx.createAnimation({
      timingFunction: "ease"
    });
    animation.opacity(1).step({ duration:200 })
    this.setData({
      isHidden: true,
      animationData: animation.export(),
    })
    this.c1 = false;
  },
  //组件传递回来的，触发trigger事件的时候就触发了
  c2: false,//防止动画还未执行完就点击下一次
  responseMyToast(e){
    if (this.c2) {
      return;
    }
    this.c2=true;
    console.log(e.detail);
    //创建动画
    var animation = wx.createAnimation({
      timingFunction: "ease"
    });
    // this.animation = animation;
    // console.log(this.animation);
    animation.opacity(0).step({ duration: 200 })
    this.setData({
      animationData: animation.export(),
    })
    let that=this;
    setTimeout(function(){
      that.setData({ isHidden: e.detail});
      that.c2 = false;
    },200)
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})