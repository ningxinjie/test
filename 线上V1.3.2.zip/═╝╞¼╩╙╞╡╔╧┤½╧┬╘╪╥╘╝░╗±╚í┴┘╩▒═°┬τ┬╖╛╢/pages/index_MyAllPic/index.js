/*
content_info[{
      year:2020,
      data:[{
        month:3
        day:05,
        data:[{fildID:[],remark:""},{fildID:[],remark:""}]
      },
      {
        month:3
        day:04,
        data:[{fildID:[],remark:""},{fildID:[],remark:""}]
      },
      ...
      ],
    }]
 */
import { CallFunction, Transformation2SingleTime, Transformation2Time, ShowToast, ShowLoading, ShowModal} from '../../utils/index.js'
Page({
  data: {
    content_info:[],
    //用于删除隐藏的数组
    content_more: [],


    //懒加载是否需要加载(与加载的列表维度保持一致)
    items_show: [],
    //懒加载个数，
    items_show_count:12,
    //滑动屏幕目前到达的高度
    slide_height: 0,
    //滑动设置次数(因为onload改变一次因此默认为1)
    set_slide_height_count: 1,
    //当前使用手机的屏幕高度
    windowHeight: 0,

    
  },

  
  async onLoad (options) {
    ShowLoading("正在拉取最新资源");
    await this.getContentData();
    var items_show = this.initItems_show();
    var content_more=this.initContent_more();
    var windowHeight = wx.getSystemInfoSync().windowHeight;
    this.setData({
      set_slide_height_count: 1,
      items_show,
      windowHeight,
      slide_height: 0.5 * windowHeight,
      content_more
    })
    wx.hideLoading();
  },
  //获取内容区数据
  async getContentData() { 
    var admin = wx.getStorageSync("admin");
    var res= await CallFunction("getDataByFiledOrder" ,{
      openid: { _openid: admin.openid},
      table_name: "beg_PicUpload",
      filed: "datetime",
      order: "desc" 
    },)
    const { data } = res.result;
    // console.log(data);
    var tempTime = [];//用于内部接收年月日
    var tempData = [];//真正需要拼接使用的变量
    var isExist_year = false;//是否已经存在当前年份
    var isExist_year_index = 0;//当前相同年的索引
    var isSame = false;//是否为同一天
    var isSame_index = 0;//同一天的索引
    var isSameRecorder = false;//是否为同一条记录
    var isSameRecorder_index = 0;//同一天的索引
    data.forEach(v => {
      isExist_year = false;
      isSame = false;
      isSameRecorder=false;
      tempTime = Transformation2SingleTime(v.datetime)
      // console.log(tempData);
      tempData.forEach((t, i) => {
        if (t.year == tempTime[0]) {
          isExist_year = true;
          isExist_year_index = i;
        }
      })
      if (isExist_year) {
        //已经存在该年份
        //是否存在同一个月，日
        tempData[isExist_year_index].data.forEach((t, i) => {
          if (t.month == tempTime[1] && t.day == tempTime[2]) {
            isSame = true;
            isSame_index = i;
          }
        })
        //年月日全部相同，判断是否为同一条记录
        if (isSame) {
          tempData[isExist_year_index].data[isSame_index].data.forEach((t,i)=>{
            if (t.datetime==v.datetime){
              isSameRecorder=true;
              isSameRecorder_index=i;
            }
          })
          if (isSameRecorder){
            //同一条记录
            tempData[isExist_year_index].data[isSame_index].data[isSameRecorder_index].fileID.push(v.fileID)
          }
          else{
            tempData[isExist_year_index].data[isSame_index].data.push({
              fileID: [v.fileID],
              remark: v.remark,
              name: v.name,
              headURL: v.headURL,
              datetimetrans: Transformation2Time(v.datetime),
              datetime: v.datetime
            })
          }
        }
        //年同月日不全相同
        else {
          tempData[isExist_year_index].data.push({
            month: tempTime[1],
            day: tempTime[2],
            data: [{
              fileID: [v.fileID],
              remark: v.remark,
              name: v.name,
              headURL: v.headURL,
              datetimetrans: Transformation2Time(v.datetime),
              datetime: v.datetime
            }]
          })
        }

      }
      else {
        // console.log(tempTime)
        tempData.push({
          year: tempTime[0],
          data: [{
            month: tempTime[1],
            day: tempTime[2],
            data: [{
              fileID: [v.fileID],
              remark: v.remark,
              name: v.name,
              headURL: v.headURL,
              datetimetrans: Transformation2Time(v.datetime),
              datetime: v.datetime
            }]
          }]
        })
      }
    })
    this.setData({
      content_info: tempData
    })
  }, 
  //点击跳转详情
  getPicDetail(e){
    const { index1, index2, index3}=e.currentTarget.dataset;
    const { content_info} =this.data;
    var transData=content_info[index1].data[index2].data[index3];
    wx.navigateTo({
      url: '../index_MyAllPic2Detail/index',
      success: function (res) {
        // 通过eventChannel向被打开页面传送数据
        res.eventChannel.emit('acceptDataFromOpenerPage', { transData })
      }
    })
  },
  async onPullDownRefresh(){
    ShowLoading("正在拉取最新资源");
    await this.getContentData();
    const { windowHeight } = this.data;
    var items_show = this.initItems_show();
    var content_more = this.initContent_more();
    this.setData({
      set_slide_height_count: 1,
      items_show,
      slide_height: 0.5 * windowHeight,
      content_more
    })
    wx.stopPullDownRefresh();
    ShowToast('拉取完成');
  },
  //初始化是否加载列表（目的是保持与显示内容维度一致）
  initItems_show() {
    //每次懒加载的个数
    const { items_show_count, content_info } = this.data;
    var items_show = [];
    var count=0;
    for (let i = 0; i < content_info.length; i++){
      items_show.push({data:[]});
      for (let j = 0; j < content_info[i].data.length; j++){
        items_show[i].data.push({ data: [] });
        for (let k = 0; k < content_info[i].data[j].data.length; k++){
          count++;
          if (count <= items_show_count){
            items_show[i].data[j].data.push(true)
          }
          else { 
            items_show[i].data[j].data.push(false)
          }
        }
      }
    }
    // console.log(items_show);
    return items_show;
  },
  //初始化是否显示列表（目的是保持与显示内容维度一致）
  initContent_more() {
    //每次懒加载的个数
    const { content_info } = this.data;
    var content_more = [];
    for (let i = 0; i < content_info.length; i++) {
      content_more.push({ yearShow:true,data: [] });
      for (let j = 0; j < content_info[i].data.length; j++) {
        //monthShow针对于后面列表，如果后面所有列表都为false那么他就为false
        content_more[i].data.push({ monthShow:true,data: [] });
        for (let k = 0; k < content_info[i].data[j].data.length; k++) {
          content_more[i].data[j].data.push(true)
        }
      }
    }
    return content_more;
  },
  //得到所有的行记录数(未使用)
  getAllRecord(){
    const { content_info } = this.data;
    var allCount = 0;
    for (let i = 0; i < content_info.length; i++) {
      for (let j = 0; j < content_info[i].data.length; j++) {
        allCount += content_info[i].data[j].data.length;
      }
    }
    return allCount;
  },
  //滑动屏幕
  onPageScroll: function (res) {
    //每次懒加载的个数
    const { items_show_count } = this.data;
    //按照滚动高度，设置接下来的图片进行加载
    let count = this.data.set_slide_height_count;
    var _this = this;
    const { windowHeight } = this.data;
    //从1.2被高度开始 每次超过一次屏幕高度设置一次继续显示加载条目图片的数量
    if (res.scrollTop > (count -0.5) * windowHeight) {
      let { items_show } = _this.data;
      var tempCount=0;
      for (let i = 0; i < items_show.length; i++) {
        for (let j = 0; j < items_show[i].data.length; j++) {
          for (let k = 0; k < items_show[i].data[j].data.length; k++){
            tempCount++;
            if (tempCount < (count + 1) * items_show_count){
              items_show[i].data[j].data[k]=true;
            }
          }
        }
      }
      _this.setData({
        items_show,
        set_slide_height_count: count + 1,
        slide_height: res.scrollTop
      })
    }
  },
  //触底将所有显示都设置为true
  onReachBottom: function () {
    let { items_show } = this.data;
    for (let i = 0; i < items_show.length; i++) {
      for (let j = 0; j < items_show[i].data.length; j++) {
        for (let k = 0; k < items_show[i].data[j].data.length; k++) {
          items_show[i].data[j].data[k] = true;
        }
      }
    }
    this.setData({ items_show })
  },
  //删除
  async deleteRecord(e){
    var isChooseOk = await ShowModal('', '是否确认删除');
    if (isChooseOk.confirm){
      ShowLoading('删除中...');
      const { index1, index2, index3 } = e.currentTarget.dataset;
      const { content_info } = this.data;
      var delData = content_info[index1].data[index2].data[index3]; // console.log(delData);
      //删除数据库
      var res_delDb = await CallFunction("deleteData", {
        table_name: "beg_PicUpload",
        datetime: { datetime: delData.datetime }
      });
      //删除存储
      for (let i = 0; i < delData.fileID.length;i++){
        var res_delS_p = await CallFunction("deleteStorage", { fileList: [delData.fileID[i]] });
      }
      //设置显示
      let {content_more} =this.data;
      content_more[index1].data[index2].data[index3]=false;
      this.checkConten_more(content_more);//数组为引用类型，因此直接写就影响原数组
      //因为删除了，所以下面的懒加载还未加载的可能要上来了，在这里我需要处理一下
      var items_show = this.detailDel_lazyLoad();
      this.setData({ content_more, items_show})
      wx.hideLoading();
    }
  },
  //检查content_more年、月日，是否需要显示
  checkConten_more(content_more){
    //先检查月日再检查年，一定是这个顺序才对
    var count=0;
    //调整月
    for (let i = 0; i < content_more.length; i++){
      for (let j = 0; j < content_more[i].data.length; j++){
        count=0;
        for (let k = 0; k < content_more[i].data[j].data.length; k++) {
          if(content_more[i].data[j].data[k]===false){count++};
        }
        if (count== content_more[i].data[j].data.length){
          content_more[i].data[j].monthShow=false;
        }
      }
    }
    //调整年
    for (let i = 0; i < content_more.length; i++){
      count = 0;
      for (let j = 0; j < content_more[i].data.length; j++){
        if (content_more[i].data[j].monthShow === false) { count++}
      }
      if (count == content_more[i].data.length){
        content_more[i].yearShow=false;
      }
    }
    return content_more;
  },
 //处理由于删除而造成懒加载上移可能仍然不显示的问题
  detailDel_lazyLoad() {
    //因为一次删除一个，因此我将懒加载下一个加载出来,然后就跳出循环
    let { items_show } = this.data;
    for (let i = 0; i < items_show.length; i++) {
      for (let j = 0; j < items_show[i].data.length; j++) {
        for (let k = 0; k < items_show[i].data[j].data.length; k++) {
          if (items_show[i].data[j].data[k] === false) {
            items_show[i].data[j].data[k] = true;
            return items_show;
          }
        }
      }
    }
    return items_show;
  }

})