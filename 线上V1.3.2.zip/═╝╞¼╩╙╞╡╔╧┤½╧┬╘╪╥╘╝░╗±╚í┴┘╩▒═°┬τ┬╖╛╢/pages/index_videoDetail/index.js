// pages/index_videoDetail/index.js
Page({

  
  data: {
    data:{},
    //视频是否加载完成
    isComplete:false
  },
  //视频是否加载完成
  checkComplete(e){
    this.setData({
      isComplete:true
    })
  },
  onLoad: function (options) {
    let that=this;
    const eventChannel = this.getOpenerEventChannel();
    eventChannel.on('acceptDataFromOpenerPage', function (data) {
      console.log(data)
      that.setData({
        data:data.data
      })
    });
   
  },
 
})