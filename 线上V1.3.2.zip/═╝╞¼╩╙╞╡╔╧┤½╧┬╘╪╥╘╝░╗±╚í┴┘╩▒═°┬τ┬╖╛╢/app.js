//app.js
App({
  onLaunch: function () {
    //云服务环境初始化
    wx.cloud.init({
      env: "nxj-huayuan"
    })
  }
})